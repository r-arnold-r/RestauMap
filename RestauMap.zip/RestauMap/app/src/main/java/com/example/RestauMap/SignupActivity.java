package com.example.RestauMap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.RestauMap.Model.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.Map;
import java.util.UUID;

public class SignupActivity extends AppCompatActivity {

    EditText editEmail, editName, editPassword, editPhone;
    Button btnSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //buttons
        btnSignUp = (Button) findViewById((R.id.btn_signup));


        //EditText fields
        editName = (EditText) findViewById(R.id.s_username) ;
        editEmail = (EditText) findViewById(R.id.s_email);
        editPassword = (EditText) findViewById(R.id.s_password);
        editPhone = (EditText) findViewById(R.id.s_phone);

        //Init Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = database.getReference("User");

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final ProgressDialog mDialog = new ProgressDialog(SignupActivity.this);
                mDialog.setMessage("Please wait...");
                mDialog.show();

                //check if text field is empty
                if(!TextUtils.isEmpty(editPhone.getText()) && !TextUtils.isEmpty(editPassword.getText()) && !TextUtils.isEmpty(editName.getText()) && !TextUtils.isEmpty(editEmail.getText())) {

                    table_user.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            //check if phone number is already registered
                            if (dataSnapshot.child(editPhone.getText().toString()).exists()) {
                                mDialog.dismiss();
                                Toast.makeText(SignupActivity.this, "Phone Number is already registered!", Toast.LENGTH_SHORT).show();
                            } else {
                                //if number is not registered
                                mDialog.dismiss();
                                //create user with the given text data
                                User user = new User(editName.getText().toString(), editPassword.getText().toString(), editEmail.getText().toString());
                                table_user.child(editPhone.getText().toString()).setValue(user);
                                Toast.makeText(SignupActivity.this, "Sign up succesful!", Toast.LENGTH_SHORT).show();
                                //return to previous activity
                                finish();
                            }
                        }


                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

                }
                //if fields are empty
                else{
                    mDialog.dismiss();
                    Toast.makeText(SignupActivity.this, "Fields are empty!", Toast.LENGTH_SHORT).show();
                }


            }
        });



    }
}