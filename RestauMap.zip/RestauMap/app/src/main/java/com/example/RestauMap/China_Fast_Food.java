package com.example.RestauMap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class China_Fast_Food extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_china__fast__food);
    }
}