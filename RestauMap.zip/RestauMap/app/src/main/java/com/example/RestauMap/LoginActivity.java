package com.example.RestauMap;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.RestauMap.Model.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    private Button btnSignIn;
    private Button button_signup;

    EditText editPhone, editPassword, editName;

    RelativeLayout rellay1, rellay2;

    /**
     * hide on start
     */
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            rellay1.setVisibility(View.VISIBLE);
            rellay2.setVisibility(View.VISIBLE);
        }
    };

    /**
     * on create
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); //lock Portrait view

        //rellays to hide for splash
        rellay1 = (RelativeLayout) findViewById(R.id.rellay1);
        rellay2 = (RelativeLayout) findViewById(R.id.rellay2);

        //buttons
        btnSignIn = (Button) findViewById(R.id.login);
        button_signup = (Button) findViewById(R.id.Signup);

        //editText fields
        editPassword = (EditText) findViewById(R.id.l_password);
        editPhone = (EditText) findViewById(R.id.l_phone);

        /**
         * Init Firebase
         */
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = database.getReference("User");


        /**
         * //Sign in button clicked
         */
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //dialog on loading
                final ProgressDialog mDialog = new ProgressDialog(LoginActivity.this);

                mDialog.setMessage("Please wait...");
                mDialog.show();

                //check if text field is empty
                if(!TextUtils.isEmpty(editPhone.getText()) && !TextUtils.isEmpty(editPassword.getText())) {

                    //get values from table
                    table_user.addValueEventListener(new ValueEventListener() {

                        //on data changed on text fields
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            //Check if user exists in database
                            if (dataSnapshot.child(editPhone.getText().toString()).exists()) {
                                //Get User Information
                                mDialog.dismiss();
                                User user = dataSnapshot.child(editPhone.getText().toString()).getValue(User.class);
                                if (user.getPassword().equals(editPassword.getText().toString())) {
                                    Toast.makeText(LoginActivity.this, "Sign in successful!", Toast.LENGTH_SHORT).show();
                                    //open map
                                    openMap();
                                } else {
                                    Toast.makeText(LoginActivity.this, "Login failed!", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                //if user doesn't exist
                                mDialog.dismiss();
                                Toast.makeText(LoginActivity.this, "Incorrect Username or Password!", Toast.LENGTH_SHORT).show();
                            }

                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }
                else{
                    //Text field is empty
                    mDialog.dismiss();
                    Toast.makeText(LoginActivity.this, "Incorrect Username or Password!", Toast.LENGTH_SHORT).show();
                }

            }

        });


        ///

        //Signup java
        button_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSignup();
            }
        });

        //splash timeout
        new Handler(Looper.myLooper()).postDelayed(runnable, 2000);
    }

    //open map
    public void openMap() {
        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);
    }

    //open register
    public void openSignup() {
        Intent intent = new Intent(this, SignupActivity.class);
        startActivity(intent);
    }
}